usatoApp = angular.module('usatoApp', ['ngResource', 'ngRoute']);
