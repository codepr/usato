# usato
Applicazione desktop creata utilizzando Node-webkit per gestione di prodotti di libreria usati.
